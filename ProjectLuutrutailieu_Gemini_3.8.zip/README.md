<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/963439ae-2b47-4110-8ad8-1b4200e35e7c

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Create `.env.local` and set `GEMINI_API_KEY=YOUR_GEMINI_API_KEY` (Gemini API only; no OpenRouter is used)
3. Run the app:
   `npm run dev`
