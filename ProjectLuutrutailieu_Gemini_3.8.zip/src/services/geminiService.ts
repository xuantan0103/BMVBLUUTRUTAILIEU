import { ExtractedDocument } from '../types';
import { PDFDocument } from 'pdf-lib';

const API_LIMIT_BYTES = 30 * 1024 * 1024; // 30MB
const PAGES_PER_CHUNK = 15;
const IMAGES_PER_CHUNK = 10;

export const uint8ArrayToBase64 = (bytes: Uint8Array): string => {
  let binary = "";
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = () => reject(new Error("Lỗi khi đọc file."));
  });
};

interface ContentPart {
  inlineData: {
    mimeType: string;
    data: string;
  };
}

const callExtractApi = async (body: any): Promise<ExtractedDocument[]> => {
  const response = await fetch('/api/extract', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const result = await response.json();
  if (!response.ok || !result.success) {
    throw new Error(result.error || result.details || 'Không thể bóc tách tài liệu này.');
  }

  const rawData: ExtractedDocument[] = result.data || [];

  // Hậu xử lý từng văn bản
  rawData.forEach(doc => {
    if (doc.startPage && /^\d$/.test(doc.startPage.toString().trim())) {
      doc.startPage = `0${doc.startPage.toString().trim()}`;
    }
    
    if (doc.docType && doc.summary) {
      let summary = doc.summary.trim();
      const docTypeLower = doc.docType.toLowerCase().trim();
      
      if (summary.toLowerCase().startsWith(docTypeLower)) {
        summary = summary.substring(docTypeLower.length).trim();
      }
      
      if (summary.length > 0) {
        // Lowercase first letter unless starting with a proper name (e.g. "Nguyễn Văn A...")
        const words = summary.split(/\s+/);
        const firstWord = words[0] || "";
        const secondWord = words[1] || "";
        const isFirstCap = /^[A-Z\u00C0-\u024F\u1EA0-\u1EF9]/.test(firstWord);
        const isSecondCap = /^[A-Z\u00C0-\u024F\u1EA0-\u1EF9]/.test(secondWord);

        if (!(isFirstCap && isSecondCap)) {
          summary = summary.charAt(0).toLowerCase() + summary.slice(1);
        }
      }
      
      doc.summary = summary;
    }
  });

  return rawData;
};

const filterValidSymbol = (rawSymbol: string | undefined): string => {
  if (!rawSymbol) return "";
  const trimmed = rawSymbol.trim();
  if (!trimmed) return "";

  const hasDigit = /\d/.test(trimmed);
  const hasLetter = /[a-zA-Z\u00C0-\u024F\u1EA0-\u1EF9]/i.test(trimmed);

  // Must contain BOTH text/letters and digits
  if (hasDigit && hasLetter) {
    return trimmed;
  }
  return "";
};

const formatAndCalculateRanges = (allResults: ExtractedDocument[]): ExtractedDocument[] => {
  return allResults.map((doc, index, array) => {
    const nextDoc = array[index + 1];
    const startPage = doc.startPage;
    let endPage: number | null = null;
    
    if (nextDoc && nextDoc.startPage && !isNaN(Number(nextDoc.startPage))) {
      endPage = Number(nextDoc.startPage) - 1;
    }

    let displayRange = startPage ? `'${startPage}` : '';
    if (startPage && endPage !== null && !isNaN(endPage) && endPage > Number(startPage)) {
      const endPageStr = endPage < 10 ? `0${endPage}` : `${endPage}`;
      displayRange = `'${startPage}-${endPageStr}`;
    }

    let formattedDate = doc.date ? (doc.date.startsWith("'") ? doc.date.substring(1) : doc.date) : "";
    if (formattedDate) {
      const parts = formattedDate.split('/');
      if (parts.length === 3) {
        let [day, month, year] = parts;
        const monthNum = parseInt(month, 10);
        if (!isNaN(monthNum)) {
          if (monthNum === 1 || monthNum === 2) {
            month = `0${monthNum}`;
          } else if (monthNum >= 3 && monthNum <= 9) {
            month = `${monthNum}`;
          } else if (monthNum >= 10 && monthNum <= 12) {
            month = `${monthNum}`;
          }
          formattedDate = `${day}/${month}/${year}`;
        }
      }
      formattedDate = `'${formattedDate}`;
    }

    return {
      ...doc,
      symbol: filterValidSymbol(doc.symbol),
      date: formattedDate || (doc.date ? `'${doc.date}'` : ''),
      pageRange: displayRange || doc.pageRange || (startPage ? `'${startPage}` : '')
    };
  });
};

export const extractDataFromFiles = async (files: File[]): Promise<ExtractedDocument[]> => {
  let allResults: ExtractedDocument[] = [];

  const pdfFiles = files.filter(f => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf'));
  const imageFiles = files.filter(f => f.type.startsWith('image/') || /\.(png|jpe?g|webp|bmp|tiff)$/i.test(f.name));

  // 1. Xử lý các tệp PDF
  for (const pdfFile of pdfFiles) {
    const arrayBuffer = await pdfFile.arrayBuffer();
    const pdfDoc = await PDFDocument.load(arrayBuffer);
    const totalPdfPages = pdfDoc.getPageCount();

    if (pdfFile.size <= API_LIMIT_BYTES && totalPdfPages <= PAGES_PER_CHUNK) {
      const base64Data = await fileToBase64(pdfFile);
      const pdfResults = await callExtractApi({
        fileBase64: base64Data,
        fileType: "application/pdf",
        fileName: pdfFile.name,
      });
      allResults.push(...pdfResults);
    } else {
      for (let i = 0; i < totalPdfPages; i += PAGES_PER_CHUNK) {
        const newDoc = await PDFDocument.create();
        const end = Math.min(i + PAGES_PER_CHUNK, totalPdfPages);
        const pagesToCopy = Array.from({ length: end - i }, (_, k) => i + k);
        const copiedPages = await newDoc.copyPages(pdfDoc, pagesToCopy);
        copiedPages.forEach(page => newDoc.addPage(page));
        const pdfBytes = await newDoc.save();
        const base64Chunk = uint8ArrayToBase64(pdfBytes);
        const chunkResults = await callExtractApi({
          fileBase64: base64Chunk,
          fileType: "application/pdf",
          fileName: `${pdfFile.name}-chunk-${Math.floor(i / PAGES_PER_CHUNK) + 1}`,
        });
        allResults.push(...chunkResults);
      }
    }
  }

  // 2. Xử lý các tệp ảnh (Hình ảnh đính kèm / nhiều ảnh)
  if (imageFiles.length > 0) {
    for (let i = 0; i < imageFiles.length; i += IMAGES_PER_CHUNK) {
      const chunk = imageFiles.slice(i, i + IMAGES_PER_CHUNK);
      const imageParts: ContentPart[] = [];

      for (const imgFile of chunk) {
        const base64 = await fileToBase64(imgFile);
        const mimeType = imgFile.type || 'image/jpeg';
        imageParts.push({ inlineData: { mimeType, data: base64 } });
      }

      if (imageParts.length > 0) {
        const imgResults = await callExtractApi({
          parts: imageParts,
          fileName: `image-batch-${Math.floor(i / IMAGES_PER_CHUNK) + 1}`,
        });
        allResults.push(...imgResults);
      }
    }
  }

  return formatAndCalculateRanges(allResults);
};

export const extractDataFromPdf = async (file: File): Promise<ExtractedDocument[]> => {
  return extractDataFromFiles([file]);
};
