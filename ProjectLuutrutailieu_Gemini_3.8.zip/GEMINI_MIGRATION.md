# Gemini API Migration

Project đã được cấu hình để gọi Gemini API trực tiếp, không sử dụng OpenRouter.

## Model

Primary: `gemini-3.8-flash`
Fallback: `gemini-3.6-flash`

## Environment

```env
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

Server nạp `.env.local` trước rồi `.env`.

## Login

Tài khoản được cấp sẵn từ `Admin0` đến `Admin10`, dùng chung mật khẩu `01032001`. Đăng nhập thành công mới hiển thị giao diện trích xuất.
