# Cấu hình Gemini API

Project sử dụng Gemini API trực tiếp qua `@google/genai`.

- Model chính: `gemini-3.8-flash`
- Model dự phòng: `gemini-3.6-flash`

Cả hai model ID trên là endpoint chính thức của Gemini API. Nếu model chính gặp lỗi tạm thời, server tự động thử model dự phòng.

## API key

Tạo `.env.local` hoặc `.env`:

```env
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

Không đưa API key vào mã nguồn hoặc commit lên Git.

## Tài khoản đăng nhập

- Tài khoản: `Admin0` đến `Admin10`
- Mật khẩu chung: `01032001`

Sau khi đăng nhập thành công, hệ thống chuyển sang giao diện trích xuất tài liệu.
